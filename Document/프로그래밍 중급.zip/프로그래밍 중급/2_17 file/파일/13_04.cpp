#include <iostream> 
#include <fstream>  
using namespace std;

void main()
{
    char ch;

    while (cin.get(ch))
        cout.put(ch);
}