//���� const_iterator //auto �� �̿��ؼ� �����ϰ� ǥ��

#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void PrintVector(const vector<int> & v)             //const
{   
    auto citer = v.begin();

    for(  ; citer != v.end(); citer++)
        cout << *citer <<"     ";
    cout << endl;
}

void main()
{
   vector<int>  v(8) ;   

   for (int i = 0; i < v.size(); i++)
        v[i] = i + 1 ;

   PrintVector( v );
}